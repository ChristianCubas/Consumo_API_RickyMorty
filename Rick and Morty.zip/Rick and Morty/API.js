async function Personajes() {
    try {
        const response = await fetch("https://rickandmortyapi.com/api/character");
        const data = await response.json();
        data.results.forEach(element => {
            let nombre_personaje = element.name;
            console.log(element)
            let especie_personaje = element.species;
            let genero_personaje = element.gender;
            let imagen_personaje = element.image;

            let contenedor = document.createElement("div");
            let imagen = document.createElement("img");
            imagen.src = imagen_personaje;
            let nombre = document.createElement("h2");
            nombre.textContent = nombre_personaje;
            let especie = document.createElement("p");
            especie.textContent = especie_personaje;
            let genero = document.createElement("p");
            genero.textContent = genero_personaje;

            contenedor.appendChild(imagen);
            contenedor.appendChild(nombre);
            contenedor.appendChild(especie);
            contenedor.appendChild(genero);
            document.body.appendChild(contenedor);
        });
        console.log("Personajes enviados exitosamente");
    } catch (error) {
        console.error("Error al cargar personajes:", error);
    }
}

Personajes()